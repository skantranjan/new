import React, { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useSSO } from '../hooks/useSSO';
import { useNavigate, useLocation } from 'react-router-dom';
import { useMsal } from '@azure/msal-react';
import { loginRequest } from '../config/msalConfig';

interface SSOInterceptorProps {
  children: React.ReactNode;
}

const SSOInterceptor: React.FC<SSOInterceptorProps> = ({ children }) => {
  const { isAuthenticated, user } = useAuth();
  const { handleSSOLogin } = useSSO();
  const navigate = useNavigate();
  const location = useLocation();
  const { instance } = useMsal();
  
  const [isCheckingAuth, setIsCheckingAuth] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [isMsalReady, setIsMsalReady] = useState(false);
  const [isAuthStateRestored, setIsAuthStateRestored] = useState(false);

  // Check if MSAL is ready
  useEffect(() => {
    const checkMsalReady = async () => {
      try {
        // Wait for MSAL to be ready
        await instance.initialize();
        setIsMsalReady(true);
        console.log('✅ MSAL is ready');
      } catch (error) {
        console.error('MSAL initialization error:', error);
        setAuthError('Failed to initialize authentication system. Please refresh the page.');
      }
    };

    checkMsalReady();
  }, [instance]);

  // Wait for authentication state to be restored from session storage
  useEffect(() => {
    // Give AuthContext time to restore user state from session storage
    const timer = setTimeout(() => {
      setIsAuthStateRestored(true);
      console.log('✅ Auth state restoration completed');
    }, 100); // Small delay to allow AuthContext to restore state

    return () => clearTimeout(timer);
  }, []);

  // Handle redirect response
  useEffect(() => {
    const handleRedirectResponse = async () => {
      try {
        const response = await instance.handleRedirectPromise();
        if (response && response.account) {
          console.log('✅ Redirect response received:', response);
          // The user will be automatically redirected to their appropriate dashboard
          // by the existing authentication flow
        }
      } catch (error) {
        console.error('❌ Error handling redirect response:', error);
      }
    };

    if (isMsalReady) {
      handleRedirectResponse();
    }
  }, [isMsalReady, instance]);

  // Auto-trigger SSO when not authenticated and MSAL is ready
  useEffect(() => {
    const performSSO = async () => {
      // Skip if MSAL is not ready, auth state not restored, already authenticated, or currently checking
      if (!isMsalReady || !isAuthStateRestored || isAuthenticated || isCheckingAuth) {
        return;
      }

      // Skip for public routes (if any) - only skip /landing, not root route
      const publicRoutes = ['/landing']; // Add any public routes here
      if (publicRoutes.includes(location.pathname)) {
        return;
      }

      // Check if user is already authenticated via MSAL but not in our context
      try {
        const accounts = instance.getAllAccounts();
        if (accounts.length > 0) {
          console.log('🔍 Found existing MSAL account, attempting silent authentication...');
          // Try to get token silently first
          try {
            const silentResult = await instance.acquireTokenSilent({
              ...loginRequest,
              account: accounts[0]
            });
            
            if (silentResult.accessToken) {
              console.log('✅ Silent authentication successful, user should be redirected');
              // Don't trigger popup login, let the existing flow handle it
              return;
            }
          } catch (silentError) {
            console.log('ℹ️ Silent authentication failed, will proceed with redirect login');
            // Instead of popup, use redirect for better reliability
            try {
              await instance.loginRedirect(loginRequest);
              return; // This will redirect, so we don't need to continue
            } catch (redirectError) {
              console.error('❌ Redirect login failed:', redirectError);
              setAuthError('Authentication failed. Please try again.');
              return;
            }
          }
        }
      } catch (error) {
        console.log('ℹ️ No existing MSAL accounts found, proceeding with redirect login');
        // Use redirect instead of popup for better reliability
        try {
          await instance.loginRedirect(loginRequest);
          return; // This will redirect, so we don't need to continue
        } catch (redirectError) {
          console.error('❌ Redirect login failed:', redirectError);
          setAuthError('Authentication failed. Please try again.');
          return;
        }
      }

      // If we reach here, it means no MSAL accounts were found
      // Store current location for after authentication
      const currentPath = location.pathname + location.search;
      sessionStorage.setItem('sso_redirect_path', currentPath);

      console.log('🔐 No existing accounts found, redirecting to login...');
      console.log('📍 Will redirect back to:', currentPath);
      
      // Use redirect login for better reliability
      try {
        await instance.loginRedirect(loginRequest);
      } catch (error: any) {
        console.error('❌ Redirect login failed:', error);
        setAuthError('Authentication failed. Please try again.');
      }
    };

    performSSO();
  }, [isMsalReady, isAuthStateRestored, isAuthenticated, isCheckingAuth, location.pathname, navigate]);

  // Show loading state while checking authentication
  if (isCheckingAuth) {
    return (
      <div style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: 'rgba(255, 255, 255, 0.9)',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 9999
      }}>
        <div style={{
          textAlign: 'center',
          padding: '40px',
          backgroundColor: 'white',
          borderRadius: '12px',
          boxShadow: '0 4px 20px rgba(0, 0, 0, 0.1)',
          maxWidth: '400px'
        }}>
          <div style={{ marginBottom: '20px' }}>
            <div className="spinner" style={{
              width: '60px',
              height: '60px',
              border: '4px solid #f3f3f3',
              borderTop: '4px solid #2196f3',
              borderRadius: '50%',
              animation: 'spin 1s linear infinite',
              margin: '0 auto'
            }}></div>
          </div>
          <h3 style={{ margin: '0 0 15px 0', color: '#333', fontSize: '20px' }}>
            Authenticating...
          </h3>
          <p style={{ margin: '0', color: '#666', fontSize: '14px' }}>
            Please complete Microsoft authentication in the popup window
          </p>
        </div>
      </div>
    );
  }

  // Show error state if authentication failed
  if (authError) {
    return (
      <div style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: 'rgba(255, 255, 255, 0.95)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 9999
      }}>
        <div style={{
          textAlign: 'center',
          padding: '40px',
          backgroundColor: 'white',
          borderRadius: '12px',
          boxShadow: '0 4px 20px rgba(0, 0, 0, 0.1)',
          maxWidth: '500px',
          border: '1px solid #ffcdd2'
        }}>
          <div style={{ marginBottom: '20px' }}>
            <div style={{
              width: '60px',
              height: '60px',
              backgroundColor: '#ffebee',
              borderRadius: '50%',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              margin: '0 auto',
              fontSize: '30px',
              color: '#d32f2f'
            }}>
              ⚠️
            </div>
          </div>
          <h3 style={{ margin: '0 0 15px 0', color: '#d32f2f', fontSize: '20px' }}>
            Authentication Failed
          </h3>
          <p style={{ margin: '0 0 20px 0', color: '#666', fontSize: '14px' }}>
            {authError}
          </p>
          <div style={{ display: 'flex', gap: '10px', justifyContent: 'center' }}>
            <button
              onClick={() => {
                setAuthError(null);
                setIsCheckingAuth(false);
                // This will trigger the useEffect again and retry SSO
              }}
              style={{
                padding: '12px 24px',
                backgroundColor: '#2196f3',
                color: 'white',
                border: 'none',
                borderRadius: '6px',
                fontSize: '14px',
                cursor: 'pointer'
              }}
            >
              Try Again
            </button>
            <button
              onClick={() => window.location.href = '/landing'}
              style={{
                padding: '12px 24px',
                backgroundColor: '#f5f5f5',
                color: '#333',
                border: '1px solid #ddd',
                borderRadius: '6px',
                fontSize: '14px',
                cursor: 'pointer'
              }}
            >
              Go to Landing Page
            </button>
          </div>
        </div>
      </div>
    );
  }

  // If authenticated, show the protected content
  if (isAuthenticated) {
    return <>{children}</>;
  }

  // If MSAL is not ready, show initialization loading
  if (!isMsalReady) {
    return (
      <div style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: 'rgba(255, 255, 255, 0.9)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 9999
      }}>
        <div style={{
          textAlign: 'center',
          padding: '40px'
        }}>
          <div className="spinner" style={{
            width: '40px',
            height: '40px',
            border: '4px solid #f3f3f3',
            borderTop: '4px solid #2196f3',
            borderRadius: '50%',
            animation: 'spin 1s linear infinite',
            margin: '0 auto 20px auto'
          }}></div>
          <p style={{ margin: 0, color: '#666' }}>Initializing authentication system...</p>
        </div>
      </div>
    );
  }

  // If not authenticated and not checking, show loading
  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      backgroundColor: 'rgba(255, 255, 255, 0.9)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 9999
    }}>
      <div style={{
        textAlign: 'center',
        padding: '40px'
      }}>
        <div className="spinner" style={{
          width: '40px',
          height: '40px',
          border: '4px solid #f3f3f3',
          borderTop: '4px solid #2196f3',
          borderRadius: '50%',
          animation: 'spin 1s linear infinite',
          margin: '0 auto 20px auto'
        }}></div>
        <p style={{ margin: 0, color: '#666' }}>Initializing authentication...</p>
      </div>
    </div>
  );
};

export default SSOInterceptor;
