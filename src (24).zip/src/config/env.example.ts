// Environment Configuration Example
// Copy this file to env.ts and modify as needed

export const ENV_EXAMPLE = {
  // Environment (development/production)
  REACT_APP_ENVIRONMENT: 'development',
  
  // API Configuration
  REACT_APP_API_BASE_URL_DEV: 'https://haleon-api-dev.apigee.net/Sustainibility-portal-channel/v1',
  REACT_APP_API_BASE_URL_PROD: 'https://sustainability-data-portal.eip.dev.haleon.com/api',
  
  // HMAC Configuration (keep these secure)
  REACT_APP_HMAC_ID: 'SustainibilityPortal',
  REACT_APP_HMAC_KEY: '0KEX8P1I7U9NJHKV1L7XHCVH6QI9XXCS',
  REACT_APP_API_KEY: 'bGMxYSqsNUb6F88L9rTY3OOMCynzZKAF'
};
