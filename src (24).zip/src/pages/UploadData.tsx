import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import Layout from '../components/Layout';
import { apiGet, apiPost } from '../utils/api';
import { useAuth } from '../contexts/AuthContext';
import * as ExcelJS from 'exceljs';

// Add CSS for spinning loader
const spinningStyle = {
  animation: 'spin 1s linear infinite'
};

// Add keyframes for spinning animation
const style = document.createElement('style');
style.textContent = `
  @keyframes spin {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
  }
`;
document.head.appendChild(style);

const UploadData: React.FC = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [selectedFromYear, setSelectedFromYear] = useState<string>('');
  const [selectedToYear, setSelectedToYear] = useState<string>('');
  const [years, setYears] = useState<Array<{id: string, period: string}>>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Excel file handling state
  const [excelData, setExcelData] = useState<any[]>([]);
  const [excelHeaders, setExcelHeaders] = useState<string[]>([]);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [fileLoading, setFileLoading] = useState(false);
  const [uploadLoading, setUploadLoading] = useState(false);
  const [uploadSuccess, setUploadSuccess] = useState<string | null>(null);
  
  // Get 3PM Code and Description from URL parameters
  const cmCode = searchParams.get('cmCode') || '';
  const cmDescription = searchParams.get('cmDescription') || '';

  // Excel file reading function
  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type
    const validTypes = [
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', // .xlsx
      'application/vnd.ms-excel', // .xls
      'text/csv' // .csv
    ];

    if (!validTypes.includes(file.type) && !file.name.match(/\.(xlsx|xls|csv)$/i)) {
      setError('Please select a valid Excel file (.xlsx, .xls) or CSV file (.csv)');
      return;
    }

    setSelectedFile(file);
    setFileLoading(true);
    setError(null);
    setUploadSuccess(null);

    // Check if it's a CSV file to determine reader method
    const isCSV = file.type === 'text/csv' || file.name.toLowerCase().endsWith('.csv');
    const reader = new FileReader();
    
    reader.onload = async (e) => {
      try {
        let jsonData: any[][];
        let excelHeaders: string[] = [];
        
        if (isCSV) {
          // Handle CSV file
          const csvText = e.target?.result as string;
          const lines = csvText.split('\n').filter(line => line.trim());
          
          if (lines.length === 0) {
            setError('The CSV file is empty');
            setFileLoading(false);
            return;
          }
          
          // Parse CSV data
          const allData = lines.map(line => {
            // Simple CSV parsing (handles basic cases)
            const values = line.split(',').map(val => val.trim().replace(/^"|"$/g, ''));
            return values;
          });
          
          // Extract headers (first row)
          excelHeaders = allData[0] || [];
          jsonData = allData.slice(1); // Remove header row from data
          
          console.log('CSV Headers detected:', excelHeaders);
          console.log('CSV Data rows:', jsonData.length);
          
        } else {
          // Handle Excel file
          const data = new Uint8Array(e.target?.result as ArrayBuffer);
          const workbook = new ExcelJS.Workbook();
          await workbook.xlsx.load(data.buffer);
          const worksheet = workbook.getWorksheet(1); // Get first worksheet
          
          if (!worksheet) {
            setError('No worksheet found in the Excel file');
            setFileLoading(false);
            return;
          }
          
          // Convert to JSON
          jsonData = [];
          worksheet.eachRow((row, rowNumber) => {
            if (rowNumber === 1) return; // Skip header row for now
            const rowData: any[] = [];
            row.eachCell((cell, colNumber) => {
              rowData[colNumber - 1] = cell.value;
            });
            jsonData.push(rowData);
          });
          
          // Add headers (first row)
          worksheet.getRow(1).eachCell((cell, colNumber) => {
            excelHeaders[colNumber - 1] = cell.value?.toString() || '';
          });
        }
        
        if (jsonData.length === 0) {
          setError('The file is empty or contains no data');
          setFileLoading(false);
          return;
        }

        // Set headers
        setExcelHeaders(excelHeaders);

        // Validate required columns
        const requiredColumns = ['SkuCode', 'SkuDescription'];
        console.log('Validating headers:', excelHeaders);
        console.log('Required columns:', requiredColumns);
        
        const missingColumns = requiredColumns.filter(col => 
          !excelHeaders.some(header => header.toLowerCase() === col.toLowerCase())
        );
        
        console.log('Missing columns:', missingColumns);

        if (missingColumns.length > 0) {
          setError(`Missing required columns: ${missingColumns.join(', ')}. Please ensure your Excel file has the required columns: ${requiredColumns.join(', ')}.`);
          setFileLoading(false);
          return;
        }

        // Extract data (remaining rows) - dynamically map required columns
        const dataRows = jsonData.map((row: any, index: number) => {
          const mappedRow: any = { _rowIndex: index + 1 };
          
          // Dynamically map each required column
          requiredColumns.forEach(column => {
            const columnIndex = excelHeaders.findIndex(header => 
              header.toLowerCase() === column.toLowerCase()
            );
            if (columnIndex !== -1) {
              // Map column names to expected API format
              if (column.toLowerCase() === 'skucode') {
                mappedRow.sku_code = row[columnIndex] || '';
              } else if (column.toLowerCase() === 'skudescription') {
                mappedRow.sku_description = row[columnIndex] || '';
              } else {
                // For any additional columns, use the column name as key
                mappedRow[column.toLowerCase()] = row[columnIndex] || '';
              }
            }
          });
          
          return mappedRow;
        }).filter(row => {
          // Filter rows that have all required data
          return requiredColumns.every(column => {
            if (column.toLowerCase() === 'skucode') {
              return row.sku_code && row.sku_code.trim() !== '';
            } else if (column.toLowerCase() === 'skudescription') {
              return row.sku_description && row.sku_description.trim() !== '';
            }
            return true; // For other columns, don't filter
          });
        });

        if (dataRows.length === 0) {
          setError(`No valid rows found. Please ensure your Excel file has data in the required columns: ${requiredColumns.join(', ')}.`);
          setFileLoading(false);
          return;
        }

        setExcelData(dataRows);
        setFileLoading(false);
        console.log('File loaded successfully:', { 
          headers: excelHeaders, 
          dataRows: dataRows.length,
          sampleData: dataRows.slice(0, 3) // Log first 3 rows for verification
        });
      } catch (err) {
        console.error('Error reading file:', err);
        setError('Error reading the file. Please ensure it\'s a valid Excel or CSV file.');
        setFileLoading(false);
      }
    };

    reader.onerror = () => {
      setError('Error reading the file');
      setFileLoading(false);
    };

    // Use appropriate reader method based on file type
    if (isCSV) {
      reader.readAsText(file);
    } else {
      reader.readAsArrayBuffer(file);
    }
  };

  // Upload data function
  const handleUploadData = async () => {
    if (!excelData.length || !selectedFile) {
      setError('Please select and read an Excel file first');
      return;
    }

    if (!selectedToYear) {
      setError('Please ensure To Period is selected');
      return;
    }

    if (!cmCode) {
      setError('CM Code is missing. Please ensure you navigated to this page with proper parameters.');
      return;
    }

    // Validate that year_id can be converted to integer
    const yearIdInt = parseInt(selectedToYear);
    if (isNaN(yearIdInt)) {
      setError('Invalid year ID. Please ensure a valid period is selected.');
      return;
    }

    // Validate that user is logged in and has a valid ID
    if (!user || !user.id) {
      setError('User not logged in. Please log in and try again.');
      return;
    }

    const createdById = parseInt(user.id.toString());
    if (isNaN(createdById)) {
      setError('Invalid user ID. Please log out and log in again.');
      return;
    }

    setUploadLoading(true);
    setError(null);
    setUploadSuccess(null);

    try {
      // Prepare data for copy-sku API - Updated to match expected format
      const uploadData = {
        cm_code: cmCode,                    // ✅ string
        year_id: yearIdInt.toString(),      // ✅ string (convert from number)
        skuData: excelData.map(row => ({
          sku_code: row.sku_code,           // ✅ string
          sku_description: row.sku_description, // ✅ string
          is_active: 1,                     // ✅ integer (1 = active)
          is_approved: 0,                   // ✅ integer (0 = not approved)
          is_display: 1,                    // ✅ integer (1 = display)
          is_sendforapproval: 0             // ✅ integer (0 = not sent for approval)
        })),
        created_by: createdById.toString()  // ✅ string (convert from number)
      };

     
      // Test API connectivity first
      console.log('🧪 Testing API connectivity...');
      try {
        const testResponse = await apiGet('/masterdata');
        console.log('✅ API connectivity test passed:', testResponse);
        console.log('🔍 Master data response structure:', {
          success: testResponse?.success,
          hasData: !!testResponse?.data,
          dataKeys: testResponse?.data ? Object.keys(testResponse.data) : 'No data'
        });
      } catch (testErr) {
        console.error('❌ API connectivity test failed:', testErr);
        console.error('❌ This might indicate network or authentication issues');
      }

      // Call the SKU upload API
      console.log('📡 Making API call to upload SKU data...');
      console.log('📤 Upload Data Payload:', JSON.stringify(uploadData, null, 2));
      console.log('🔍 Payload Data Types:');
      console.log('  - cm_code type:', typeof uploadData.cm_code);
      console.log('  - year_id type:', typeof uploadData.year_id);
      console.log('  - created_by type:', typeof uploadData.created_by);
      console.log('  - skuData length:', uploadData.skuData.length);
      console.log('  - First SKU sample:', uploadData.skuData[0]);
      console.log('  - First SKU field types:', {
        sku_code: typeof uploadData.skuData[0].sku_code,
        sku_description: typeof uploadData.skuData[0].sku_description,
        is_active: typeof uploadData.skuData[0].is_active,
        is_approved: typeof uploadData.skuData[0].is_approved,
        is_display: typeof uploadData.skuData[0].is_display,
        is_sendforapproval: typeof uploadData.skuData[0].is_sendforapproval
      });
      console.log('🔍 Debug - Data validation:');
      console.log('  - cm_code:', typeof uploadData.cm_code, '=', uploadData.cm_code);
      console.log('  - year_id:', typeof uploadData.year_id, '=', uploadData.year_id);
      console.log('  - created_by:', typeof uploadData.created_by, '=', uploadData.created_by);
      console.log('  - skuData length:', uploadData.skuData.length);
      console.log('  - First SKU sample:', uploadData.skuData[0]);
      
      console.log('🌐 Making API call to /sku/clones...');
      
      // Use the exact structure expected by the API controller
      const alternativePayload = {
        cm_code: cmCode,                    // ✅ string (required)
        year_id: yearIdInt.toString(),      // ✅ string (required by controller)
        skuData: excelData.map(row => ({
          sku_code: row.sku_code.trim(),           // ✅ string (required)
          sku_description: row.sku_description.trim() // ✅ string (required)
        })),
        created_by: createdById.toString()  // ✅ string (optional, will default to 'system.user')
      };
      
      console.log('🔄 Using /sku/clones with correct payload structure:', JSON.stringify(alternativePayload, null, 2));
      
      const response = await apiPost('/sku/clones', alternativePayload);
      console.log('📡 Raw API Response:', response);
      
     
      console.log('📊 Response Analysis:');
      console.log('  - Response exists:', !!response);
      console.log('  - Response.success:', response?.success);
      console.log('  - Response.message:', response?.message);
      console.log('  - Response.data:', response?.data);
      console.log('  - Response type:', typeof response);
      
      // Check for processing errors
      if (response?.data) {
        console.log('🔍 Data Processing Details:');
        console.log('  - Total SKUs:', response.data.total_skus);
        console.log('  - Processed SKUs:', response.data.processed_skus?.length || 0);
        console.log('  - Errors count:', response.data.errors?.length || 0);
        
        if (response.data.errors && response.data.errors.length > 0) {
          console.error('❌ Processing Errors:');
          console.error('  - First few errors:', JSON.stringify(response.data.errors.slice(0, 3), null, 2));
          console.error('  - All errors:', JSON.stringify(response.data.errors, null, 2));
        }
        
        if (response.data.processed_skus && response.data.processed_skus.length > 0) {
          console.log('✅ Successfully Processed SKUs:');
          console.log('  - Processed SKUs:', response.data.processed_skus);
        }
      }
      
      // Check if any SKUs were actually processed successfully
      const processedCount = response?.data?.processed_skus?.length || 0;
      const errorCount = response?.data?.errors?.length || 0;
      
      if (response && response.success) {
        if (processedCount > 0) {
          setUploadSuccess(`Successfully uploaded ${processedCount} SKU records! ${errorCount > 0 ? `${errorCount} records had errors.` : ''}`);
        } else {
          setError(`Upload failed: ${errorCount} SKU records had errors. No data was inserted. Check console for error details.`);
        }
        
        setExcelData([]);
        setExcelHeaders([]);
        setSelectedFile(null);
        console.log('✅ SKU data upload process completed:', response);
      } else {
        console.error('❌ Upload failed - Full response:', response);
        console.error('❌ Upload failed - Response keys:', Object.keys(response || {}));
        throw new Error(response?.message || 'Upload failed - No success response received');
      }
      
    } catch (err) {
      console.error('💥 Error uploading SKU data:', err);
      console.error('💥 Error details:', {
        name: err instanceof Error ? err.name : 'Unknown',
        message: err instanceof Error ? err.message : 'Unknown error',
        stack: err instanceof Error ? err.stack : 'No stack trace'
      });
      setError(`Error uploading data: ${err instanceof Error ? err.message : 'Please try again.'}`);
    } finally {
      console.log('🏁 Upload process completed');
      setUploadLoading(false);
    }
  };

  // Fetch years from API
  useEffect(() => {
    const fetchYears = async () => {
      try {
        console.log('Fetching years for UploadData...');
        setLoading(true);
        setError(null);
        
        // Use the master data API endpoint
        const result = await apiGet('/masterdata');
        console.log('Years API result:', result);
        
        // Extract periods data from the master data API response
        let yearsData = [];
        
        if (result && result.success && result.data && result.data.periods) {
          // Master data API response format
          yearsData = result.data.periods;
          console.log('Extracted periods from master data:', yearsData);
        } else {
          console.warn('Unexpected master data API response format:', result);
          yearsData = [];
        }
        
                // Process the periods data into the expected format and sort by year in descending order
        const processedYears = yearsData.map((item: any) => {
          if (item && typeof item === 'object' && item.period && item.id) {
            return { id: item.id.toString(), period: item.period };
          }
          return null;
        }).filter(Boolean);
        
        // Sort periods by ID value in descending order (highest ID first)
        const sortedYears = processedYears.sort((a: any, b: any) => {
          const idA = parseInt(a.id);
          const idB = parseInt(b.id);
          
          return idB - idA; // Descending order by ID value
        });
        
        console.log('Processed and sorted years:', sortedYears);
        setYears(sortedYears);
        
                 if (sortedYears.length === 0) {
           console.warn('No periods found in master data API response');
           setError('No periods available in the system.');
         } else {
           // Auto-select based on sorted IDs (descending order)
           // From Period: Second highest ID (index 1)
           // To Period: Highest ID (index 0)
           if (sortedYears.length >= 2) {
             // From Period: Second highest ID
             const fromPeriodOption = sortedYears[1]; // Index 1 = second highest
             setSelectedFromYear(fromPeriodOption.id);
             console.log('Auto-selected From Period (second highest ID):', fromPeriodOption.period, 'ID:', fromPeriodOption.id);
             
             // To Period: Highest ID
             const toPeriodOption = sortedYears[0]; // Index 0 = highest
             setSelectedToYear(toPeriodOption.id);
             console.log('Auto-selected To Period (highest ID):', toPeriodOption.period, 'ID:', toPeriodOption.id);
           } else if (sortedYears.length === 1) {
             // If only one period available, use it for both
             setSelectedFromYear(sortedYears[0].id);
             setSelectedToYear(sortedYears[0].id);
             console.log('Only one period available, using for both:', sortedYears[0].period);
           }
         }
        
      } catch (err) {
        console.error('Error fetching years from master data API:', err);
        setError('Failed to load periods. Please try again.');
        setYears([]);
      } finally {
        setLoading(false);
      }
    };
    fetchYears();
  }, []);



  return (
    <Layout>
      <div className="mainInternalPages">
        <div style={{ marginBottom: 8 }}>
        </div>
        {/* Dashboard Header */}
        <div style={{ 
          display: 'flex', 
          justifyContent: 'space-between', 
          alignItems: 'center',
          padding: '12px 0'
        }}>
          <div className="commonTitle">
            <div className="icon">
              <i className="ri-upload-cloud-2-fill"></i>
            </div>
            <h1>Upload Data</h1>
          </div>
          <button
            onClick={() => navigate(-1)}
            style={{
              background: 'linear-gradient(135deg, #30ea03 0%, #28c402 100%)',
              border: 'none',
              color: '#000',
              fontSize: 14,
              fontWeight: 600,
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              padding: '2px 16px',
              borderRadius: '8px',
              transition: 'all 0.3s ease',
              minWidth: '100px',
              justifyContent: 'center'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.transform = 'translateY(-2px)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.transform = 'translateY(0)';
            }}
          >
            <i className="ri-arrow-left-line" style={{ fontSize: 18, marginRight: 6 }} />
            Back
          </button>
        </div>

        {/* 3PM Info Section */}
        <div className="filters CMDetails">
          <div className="row">
            <div className="col-sm-12 ">
              <ul style={{ display: 'flex', alignItems: 'center', padding: '6px 15px 8px' }}>
                <li><strong>3PM Code: </strong> {cmCode}</li>
                <li> | </li>
                <li><strong>3PM Description: </strong> {cmDescription}</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Filters Section */}
        <div className="row"> 
          <div className="col-sm-12">
            <div className="filters">
              <ul>
                <li>
                  <div className="fBold">From Period</div>
                  <div className="form-control">
                                         <select
                       value={selectedFromYear}
                       style={{
                         width: '100%',
                         padding: '8px 12px',
                         borderRadius: '4px',
                         fontSize: '14px',
                         backgroundColor: '#f8f9fa',
                         border: '1px solid #ddd',
                         outline: 'none',
                         cursor: 'not-allowed'
                       }}
                       disabled={true}
                     >
                      <option value="">Select From Period</option>
                                             {years.length === 0 ? (
                         <option value="" disabled>Loading periods...</option>
                       ) : (
                         // Show second highest ID period for From dropdown
                         years.length >= 2 ? (
                           <option value={years[1].id}>
                             {years[1].period}
                           </option>
                         ) : years.length === 1 ? (
                           <option value={years[0].id}>
                             {years[0].period}
                           </option>
                         ) : null
                       )}
                    </select>
                  </div>
                </li>
                <li>
                  <div className="fBold">To Period</div>
                  <div className="form-control">
                                         <select
                       value={selectedToYear}
                       style={{
                         width: '100%',
                         padding: '8px 12px',
                         borderRadius: '4px',
                         fontSize: '14px',
                         backgroundColor: '#f8f9fa',
                         border: '1px solid #ddd',
                         outline: 'none',
                         cursor: 'not-allowed'
                       }}
                       disabled={true}
                     >
                      <option value="">Select To Period</option>
                                             {years.length === 0 ? (
                         <option value="" disabled>Loading periods...</option>
                       ) : (
                         // Show highest ID period for To dropdown
                         years.length >= 1 ? (
                           <option value={years[0].id}>
                             {years[0].period}
                           </option>
                         ) : null
                       )}
                    </select>
                  </div>
                </li>
                                                  <li>
                    <div className="fBold">Browse Excel File</div>
                    <div className="form-control">
                      <input
                        type="file"
                        accept=".xlsx,.xls,.csv"
                         onChange={handleFileUpload}
                        style={{
                          width: '100%',
                          padding: '8px 12px',
                          borderRadius: '4px',
                          fontSize: '14px',
                          backgroundColor: '#fff',
                          border: '1px solid #ddd',
                          outline: 'none'
                        }}
                      />
                      <div style={{ 
                        marginTop: '4px', 
                        fontSize: '11px', 
                        color: '#666',
                        fontStyle: 'italic'
                      }}>
                        Required columns: SkuCode, SkuDescription
                      </div>
                     {selectedFile && (
                       <div style={{ 
                         marginTop: '8px', 
                         fontSize: '12px', 
                         color: '#28a745',
                         display: 'flex',
                         alignItems: 'center',
                         gap: '4px'
                       }}>
                         <i className="ri-check-line"></i>
                         {selectedFile.name} ({Math.round(selectedFile.size / 1024)} KB)
                         <button
                           type="button"
                           onClick={() => {
                             setSelectedFile(null);
                             setExcelData([]);
                             setExcelHeaders([]);
                             setError(null);
                             setUploadSuccess(null);
                           }}
                           style={{
                             marginLeft: '8px',
                             background: 'none',
                             border: 'none',
                             color: '#dc3545',
                             cursor: 'pointer',
                             fontSize: '12px',
                             padding: '2px 6px',
                             borderRadius: '3px'
                           }}
                           title="Clear file"
                         >
                           <i className="ri-close-line"></i>
                         </button>
                       </div>
                     )}
                   </div>
                 </li>
                 <li>
                                       <button 
                                         className="btnCommon btnGreen filterButtons" 
                                         onClick={handleUploadData} 
                                         disabled={!excelData.length || !selectedFile || uploadLoading}
                                       >
                      <span>{uploadLoading ? 'Uploading...' : 'Upload'}</span>
                      <i 
                        className={uploadLoading ? 'ri-loader-4-line' : 'ri-upload-line'} 
                        style={uploadLoading ? spinningStyle : {}}
                      ></i>
                    </button>
                 </li>
              </ul>
            </div>
          </div>
        </div>

        

        {/* File Loading Indicator */}
        {fileLoading && (
          <div style={{ 
            textAlign: 'center', 
            padding: '40px', 
            color: '#666',
            marginTop: '20px'
          }}>
            <i className="ri-loader-4-line" style={{ fontSize: '24px', color: '#666', ...spinningStyle }}></i>
            <p>Reading Excel file...</p>
          </div>
        )}

        {/* Error Display */}
        {error && (
          <div style={{ 
            background: '#f8d7da', 
            color: '#721c24', 
            padding: '15px 20px', 
            borderRadius: '8px', 
            marginTop: '20px',
            border: '1px solid #f5c6cb',
            display: 'flex',
            alignItems: 'center'
          }}>
            <i className="ri-error-warning-line" style={{ marginRight: '8px', fontSize: '18px' }}></i>
            {error}
          </div>
        )}

        {/* Success Display */}
        {uploadSuccess && (
          <div style={{ 
            background: '#d4edda', 
            color: '#155724', 
            padding: '15px 20px', 
            borderRadius: '8px', 
            marginTop: '20px',
            border: '1px solid #c3e6cb',
            display: 'flex',
            alignItems: 'center'
          }}>
            <i className="ri-check-line" style={{ marginRight: '8px', fontSize: '18px' }}></i>
            {uploadSuccess}
          </div>
        )}

        {loading && (
          <div style={{ textAlign: 'center', padding: '40px', color: '#666' }}>
            <i className="ri-loader-4-line" style={{ fontSize: '24px', color: '#666', ...spinningStyle }}></i>
            <p>Loading periods...</p>
          </div>
        )}


      </div>
    </Layout>
  );
};

export default UploadData; 