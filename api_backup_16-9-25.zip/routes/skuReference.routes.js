const { getSkuDetailsByReferenceController, getSkuDetailsByPeriodAndCmController } = require('../controllers/controller.getSkuReference');
const bearerTokenMiddleware = require('../middleware/middleware.bearer');

async function skuReferenceRoutes(fastify, options) {
  // Protected routes - requires Bearer token
  fastify.get('/api/sku-reference/:sku_reference', {
    preHandler: bearerTokenMiddleware
  }, getSkuDetailsByReferenceController);
  
  fastify.get('/api/getskureference/:period/:cm_code', {
    preHandler: bearerTokenMiddleware
  }, getSkuDetailsByPeriodAndCmController);
}

module.exports = skuReferenceRoutes; 