const pool = require('../config/db.config');

/**
 * Get component audit log records by component_id
 */
async function getComponentAuditLogByComponentId(componentId) {
  const query = `
    SELECT id, cm_code, sku_code, component_code, version, component_packaging_type_id,
           period_id, component_valid_from, component_valid_to, created_by, action_type,
           action_reason, old_values, new_values, changed_by, changed_at, change_summary,
           componentvaliditydatefrom, componentvaliditydateto, componentid
    FROM sdp_sku_component_mapping_details_auditlog 
    WHERE componentid = $1 
    ORDER BY changed_at DESC
  `;

  const result = await pool.query(query, [componentId]);
  return result.rows;
}

module.exports = { getComponentAuditLogByComponentId }; 