const { BlobServiceClient } = require('@azure/storage-blob');
const { AzureCliCredential, DefaultAzureCredential } = require('@azure/identity');
const { URL } = require('url');
const axios = require('axios');

/**
 * PDF Streaming Controller
 * Streams PDF files from Azure Blob Storage with security validation
 */

// Azure Blob Storage configuration (same as utils/azureBlobStorage.js)
const ALLOWED_BLOB_ACCOUNT = 'ukssdptldev001'; // Your Azure storage account name
const ALLOWED_CONTAINERS = ['sdpdevstoragecontainer', 'adobesign', 'pdfs']; // Allowed container names

// Production configuration (same as utils/azureBlobStorage.js)
const accountName = process.env['AZURE-STORAGE-ACCOUNT'];
const containerName = process.env['AZURE-CONTAINER-NAME'];
const blobUrl = `https://${accountName}.blob.core.windows.net`;

// Choose authentication method based on environment (same as utils/azureBlobStorage.js)
let credential;
if (process.env['NODE-ENV'] === 'production') {
  if (process.env['AZURE-USE-MANAGED-IDENTITY'] === 'true') {
    // Use Managed Identity (recommended for Azure App Service)
    credential = new DefaultAzureCredential();
  } else if (process.env['AZURE-STORAGE-CONNECTION-STRING']) {
    // Use connection string
    credential = null; // Will use connection string directly
  } else {
    // Fallback to Azure CLI (for local development)
    credential = new AzureCliCredential();
  }
} else {
  // Development environment - EIP Dev
  if (process.env['AZURE-USE-CONNECTION-STRING'] === 'true' && process.env['AZURE-STORAGE-CONNECTION-STRING']) {
    // Use connection string for EIP Dev
    credential = null; // Will use connection string directly
  } else {
    // Fallback to Azure CLI (for local development)
    credential = new AzureCliCredential();
  }
}

/**
 * Validate Azure Blob Storage URL
 * @param {string} pdfUrl - The URL to validate
 * @returns {Object} Validation result with parsed components
 */
function validateBlobUrl(pdfUrl) {
  try {
    const url = new URL(pdfUrl);
    
    // Check if it's HTTPS
    if (url.protocol !== 'https:') {
      return {
        isValid: false,
        error: 'URL must use HTTPS protocol'
      };
    }
    
    // Extract account name from hostname
    const hostnameParts = url.hostname.split('.');
    if (hostnameParts.length < 3) {
      return {
        isValid: false,
        error: 'Invalid Azure Blob Storage URL format'
      };
    }
    
    const accountName = hostnameParts[0];
    
    // Validate account name
    if (accountName !== ALLOWED_BLOB_ACCOUNT) {
      return {
        isValid: false,
        error: `URL must be from allowed Azure storage account: ${ALLOWED_BLOB_ACCOUNT}`
      };
    }
    
    // Extract container and blob path
    const pathParts = url.pathname.split('/').filter(part => part.length > 0);
    if (pathParts.length < 2) {
      return {
        isValid: false,
        error: 'URL must contain container and blob path'
      };
    }
    
    const containerName = pathParts[0];
    const blobPath = pathParts.slice(1).join('/');
    
    // Validate container name
    if (!ALLOWED_CONTAINERS.includes(containerName)) {
      return {
        isValid: false,
        error: `Container '${containerName}' is not allowed. Allowed containers: ${ALLOWED_CONTAINERS.join(', ')}`
      };
    }
    
    return {
      isValid: true,
      accountName,
      containerName,
      blobPath,
      fullUrl: pdfUrl
    };
    
  } catch (error) {
    return {
      isValid: false,
      error: 'Invalid URL format'
    };
  }
}

/**
 * Get file extension from blob path
 * @param {string} blobPath - The blob path
 * @returns {string} File extension
 */
function getFileExtension(blobPath) {
  const lastDotIndex = blobPath.lastIndexOf('.');
  if (lastDotIndex === -1) return '';
  return blobPath.substring(lastDotIndex + 1).toLowerCase();
}

/**
 * Generate safe filename for Content-Disposition header
 * @param {string} blobPath - The blob path
 * @returns {string} Safe filename
 */
function generateSafeFilename(blobPath) {
  const filename = blobPath.split('/').pop();
  // Remove or replace unsafe characters
  return filename.replace(/[^a-zA-Z0-9._-]/g, '_');
}

/**
 * Stream PDF from Azure Blob Storage
 * @param {Object} request - Fastify request object
 * @param {Object} reply - Fastify reply object
 */
async function streamPdfController(request, reply) {
  try {
    console.log('📄 PDF Stream Request Started');
    console.log('🔧 Azure Connection String available:', !!process.env['AZURE-STORAGE-CONNECTION-STRING']);
    console.log('🔧 Azure Connection String length:', process.env['AZURE-STORAGE-CONNECTION-STRING'] ? process.env['AZURE-STORAGE-CONNECTION-STRING'].length : 0);
    console.log('🔧 NODE_ENV:', process.env['NODE-ENV']);
    console.log('🔧 AZURE_USE_CONNECTION_STRING:', process.env['AZURE-USE-CONNECTION-STRING']);
    console.log('🔧 PATH contains Azure CLI:', process.env.PATH?.includes('Azure') || process.env.PATH?.includes('azure-cli') || 'Not found');
    
    // Extract pdfUrl from query parameters
    const { pdfUrl } = request.query;
    
    if (!pdfUrl) {
      console.log('❌ Missing pdfUrl parameter');
      return reply.code(400).send({
        success: false,
        message: 'pdfUrl query parameter is required',
        error: 'MISSING_PDF_URL'
      });
    }
    
    console.log(`🔍 Processing PDF URL: ${pdfUrl}`);
    
    // Validate the URL
    const urlValidation = validateBlobUrl(pdfUrl);
    if (!urlValidation.isValid) {
      console.log(`❌ URL validation failed: ${urlValidation.error}`);
      return reply.code(400).send({
        success: false,
        message: 'Invalid PDF URL',
        error: 'INVALID_PDF_URL',
        details: urlValidation.error
      });
    }
    
    const { containerName, blobPath } = urlValidation;
    console.log(`✅ URL validated - Container: ${containerName}, Blob: ${blobPath}`);
    
    // Initialize Azure Blob Service Client (try multiple authentication methods)
    let blobServiceClient;
    
    // Try connection string first if available
    if (process.env['AZURE-STORAGE-CONNECTION-STRING'] && process.env['AZURE-STORAGE-CONNECTION-STRING'].length > 50) {
      console.log('🔑 Using Azure Storage Connection String');
      try {
        blobServiceClient = BlobServiceClient.fromConnectionString(process.env['AZURE-STORAGE-CONNECTION-STRING']);
      } catch (error) {
        console.error('❌ Connection string failed, trying Azure CLI:', error.message);
        console.log('🔑 Falling back to Azure CLI Credentials');
        blobServiceClient = new BlobServiceClient(blobUrl, credential);
      }
    } else {
      console.log('🔑 Using Azure CLI Credentials (connection string too short)');
      try {
        blobServiceClient = new BlobServiceClient(blobUrl, credential);
      } catch (error) {
        console.error('❌ Azure CLI authentication failed:', error.message);
        console.log('🔄 Trying DefaultAzureCredential as fallback...');
        
        try {
          const defaultCredential = new DefaultAzureCredential();
          blobServiceClient = new BlobServiceClient(blobUrl, defaultCredential);
          console.log('✅ DefaultAzureCredential succeeded');
        } catch (defaultError) {
          console.error('❌ All authentication methods failed:', defaultError.message);
          return reply.code(500).send({
            success: false,
            message: 'Azure authentication failed. Please check your Azure setup.',
            error: 'AUTHENTICATION_ERROR',
            details: 'All authentication methods failed. Please ensure Azure CLI is installed and run "az login", or provide a valid connection string.',
            troubleshooting: [
              '1. Install Azure CLI: winget install Microsoft.AzureCLI',
              '2. Run: az login',
              '3. Restart your terminal and Node.js server',
              '4. Or provide a valid AZURE-STORAGE-CONNECTION-STRING'
            ]
          });
        }
      }
    }
    
    const containerClient = blobServiceClient.getContainerClient(containerName);
    const blobClient = containerClient.getBlobClient(blobPath);
    
    console.log(`🔗 Connecting to Azure Blob Storage...`);
    
    // Check if blob exists
    const blobExists = await blobClient.exists();
    if (!blobExists) {
      console.log(`❌ Blob not found: ${blobPath}`);
      return reply.code(404).send({
        success: false,
        message: 'PDF file not found',
        error: 'PDF_NOT_FOUND',
        container: containerName,
        blob: blobPath
      });
    }
    
    // Get blob properties
    const blobProperties = await blobClient.getProperties();
    const contentLength = blobProperties.contentLength;
    const lastModified = blobProperties.lastModified;
    
    console.log(`📊 Blob properties - Size: ${contentLength} bytes, Modified: ${lastModified}`);
    
    // Stream the blob
    const downloadResponse = await blobClient.download();
    const stream = downloadResponse.readableStreamBody;
    
    // Set appropriate headers
    reply.header('Content-Type', blobProperties.contentType || 'application/pdf');
    reply.header('Content-Length', contentLength);
    reply.header('Content-Disposition', `inline; filename="${blobPath.split('/').pop()}"`);
    reply.header('Cache-Control', 'public, max-age=3600');
    
    console.log(`✅ Streaming PDF via Azure CLI: ${blobPath}`);
    
    // Pipe the stream to the response
    return reply.send(stream);
    
  } catch (error) {
    console.error('❌ PDF Stream Error:', error);
    
    // Handle specific Azure errors
    if (error.code === 'ContainerNotFound') {
      return reply.code(404).send({
        success: false,
        message: 'Container not found',
        error: 'CONTAINER_NOT_FOUND'
      });
    }
    
    if (error.code === 'BlobNotFound') {
      return reply.code(404).send({
        success: false,
        message: 'PDF file not found',
        error: 'BLOB_NOT_FOUND'
      });
    }
    
    if (error.code === 'AuthenticationFailed') {
      return reply.code(401).send({
        success: false,
        message: 'Azure authentication failed',
        error: 'AZURE_AUTH_FAILED'
      });
    }
    
    // Generic error response
    return reply.code(500).send({
      success: false,
      message: 'Internal server error while streaming PDF',
      error: 'INTERNAL_ERROR',
      details: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
}

/**
 * Health check for PDF streaming service
 * @param {Object} request - Fastify request object
 * @param {Object} reply - Fastify reply object
 */
async function pdfStreamHealthController(request, reply) {
  try {
    // Initialize Azure Blob Service Client
    let blobServiceClient;
    if (process.env['NODE-ENV'] === 'production' && process.env['AZURE-STORAGE-CONNECTION-STRING']) {
      // Use connection string for production
      blobServiceClient = BlobServiceClient.fromConnectionString(process.env['AZURE-STORAGE-CONNECTION-STRING']);
    } else {
      // Use credential-based authentication
      blobServiceClient = new BlobServiceClient(blobUrl, credential);
    }
    
    // Test connection by listing containers
    const containers = blobServiceClient.listContainers();
    await containers.next(); // Just check if we can connect
    
    return reply.send({
      success: true,
      message: 'PDF streaming service is healthy',
      status: 'healthy',
      azure: {
        configured: true,
        account: ALLOWED_BLOB_ACCOUNT,
        allowedContainers: ALLOWED_CONTAINERS
      }
    });
    
  } catch (error) {
    console.error('❌ PDF Stream Health Check Error:', error);
    return reply.code(503).send({
      success: false,
      message: 'PDF streaming service is unhealthy',
      status: 'unhealthy',
      error: error.message
    });
  }
}

module.exports = {
  streamPdfController,
  pdfStreamHealthController
};