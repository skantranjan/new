const pool = require('../config/db.config');

/**
 * Get component audit log records by component_id (legacy function)
 */
async function getComponentAuditLogByComponentId(componentId) {
  const query = `
    SELECT id, cm_code, sku_code, component_code, version, component_packaging_type_id,
           period_id, component_valid_from, component_valid_to, created_by, action_type,
           action_reason, old_values, new_values, changed_by, changed_at, change_summary,
           componentvaliditydatefrom, componentvaliditydateto, componentid
    FROM sdp_sku_component_mapping_details_auditlog 
    WHERE componentid = $1 
    ORDER BY changed_at DESC
  `;

  const result = await pool.query(query, [componentId]);
  return result.rows;
}

/**
 * Get component audit log records by component_code from both tables
 */
async function getComponentAuditLogByComponentCode(componentCode) {
  const query = `
    -- Get data from sdp_sku_component_mapping_details_auditlog table
    SELECT 
      'mapping' as table_source,
      id, 
      cm_code, 
      sku_code, 
      component_code, 
      version, 
      component_packaging_type_id,
      period_id, 
      component_valid_from, 
      component_valid_to, 
      created_by, 
      action_type,
      action_reason, 
      old_values, 
      new_values, 
      changed_by, 
      changed_at, 
      change_summary,
      componentvaliditydatefrom, 
      componentvaliditydateto, 
      componentid,
      -- Additional fields for mapping table
      NULL as formulation_reference,
      NULL as material_type_id,
      NULL as components_reference,
      NULL as component_description,
      NULL as component_material_group,
      NULL as component_quantity,
      NULL as component_uom_id,
      NULL as component_base_quantity,
      NULL as component_base_uom_id,
      NULL as percent_w_w,
      NULL as evidence,
      NULL as component_packaging_material,
      NULL as helper_column,
      NULL as component_unit_weight,
      NULL as weight_unit_measure_id,
      NULL as percent_mechanical_pcr_content,
      NULL as percent_mechanical_pir_content,
      NULL as percent_chemical_recycled_content,
      NULL as percent_bio_sourced,
      NULL as material_structure_multimaterials,
      NULL as component_packaging_color_opacity,
      NULL as component_packaging_level_id,
      NULL as component_dimensions,
      NULL as packaging_specification_evidence,
      NULL as evidence_of_recycled_or_bio_source,
      NULL as last_update_date,
      NULL as category_entry_id,
      NULL as data_verification_entry_id,
      NULL as user_id,
      NULL as signed_off_by,
      NULL as signed_off_date,
      NULL as mandatory_fields_completion_status,
      NULL as evidence_provided,
      NULL as document_status,
      NULL as is_active,
      NULL as created_date,
      NULL as year,
      NULL as component_unit_weight_id
    FROM sdp_sku_component_mapping_details_auditlog 
    WHERE component_code = $1
    
    UNION ALL
    
    -- Get data from sdp_component_details_auditlog table
    SELECT 
      'details' as table_source,
      id,
      cm_code,
      NULL as sku_code,
      component_code,
      version,
      component_packaging_type_id,
      periods as period_id,
      componentvaliditydatefrom as component_valid_from,
      componentvaliditydateto as component_valid_to,
      created_by,
      NULL as action_type,
      NULL as action_reason,
      NULL as old_values,
      NULL as new_values,
      created_by as changed_by,
      created_date as changed_at,
      helper_column as change_summary,
      componentvaliditydatefrom,
      componentvaliditydateto,
      component_id as componentid,
      -- All the detailed component fields
      formulation_reference,
      material_type_id,
      components_reference,
      component_description,
      component_material_group,
      component_quantity,
      component_uom_id,
      component_base_quantity,
      component_base_uom_id,
      percent_w_w,
      evidence,
      component_packaging_material,
      helper_column,
      component_unit_weight,
      weight_unit_measure_id,
      percent_mechanical_pcr_content,
      percent_mechanical_pir_content,
      percent_chemical_recycled_content,
      percent_bio_sourced,
      material_structure_multimaterials,
      component_packaging_color_opacity,
      component_packaging_level_id,
      component_dimensions,
      packaging_specification_evidence,
      evidence_of_recycled_or_bio_source,
      last_update_date,
      category_entry_id,
      data_verification_entry_id,
      user_id,
      signed_off_by,
      signed_off_date,
      mandatory_fields_completion_status,
      evidence_provided,
      document_status,
      is_active,
      created_date,
      year,
      component_unit_weight_id
    FROM sdp_component_details_auditlog 
    WHERE component_code = $1
    
    ORDER BY changed_at DESC, table_source ASC
  `;

  const result = await pool.query(query, [componentCode]);
  return result.rows;
}

module.exports = { 
  getComponentAuditLogByComponentId,
  getComponentAuditLogByComponentCode 
}; 