const db = require('../config/db.config');

/**
 * Get comprehensive audit log data with detailed component information
 * 
 * This API endpoint retrieves comprehensive audit log data from multiple tables
 * including SKU component mapping details, component details, SKU details, and master data.
 * 
 * @param {Object} request - Fastify request object
 * @param {Object} request.body - Request body containing filter parameters
 * @param {string} request.body.cm_code - CM Code filter (optional)
 * @param {string} request.body.period_id - Period ID filter (optional)
 * @param {string} request.body.sku_code - SKU Code filter (optional)
 * @param {string} request.body.component_code - Component Code filter (optional)
 * @param {string} request.body.packaging_type - Packaging Type filter (optional)
 * @param {boolean} request.body.is_active - Active status filter (optional)
 * @param {number} request.body.limit - Number of records per page (default: 100, max: 1000)
 * @param {number} request.body.offset - Page offset for pagination (default: 0)
 * 
 * @param {Object} reply - Fastify reply object
 * @returns {Object} Response with audit log data, pagination info, and query summary
 */
const getAuditLog = async (request, reply) => {
    try {
        // Extract filter parameters from request body
        const { 
            cm_code, 
            period_id,
            sku_code,
            component_code,
            packaging_type,
            is_active,
            limit = 100,
            offset = 0
        } = request.body; // Using POST method for complex filtering

        // Validate required cm_code parameter (optional for this endpoint)
        if (!cm_code) {
            // If no cm_code provided, we'll get all data without cm_code filter
            console.log('No cm_code provided - retrieving all data');
        }

        // Initialize dynamic query building variables
        let whereConditions = []; // Array to store WHERE conditions
        let queryParams = [];     // Array to store query parameters
        let paramIndex = 1;       // Parameter index counter for PostgreSQL

        // Debug logging for troubleshooting
        console.log('🔍 === AUDIT LOGS API DEBUG ===');
        console.log('📋 Request Parameters:', {
            cm_code,
            period_id,
            sku_code,
            component_code,
            packaging_type,
            is_active,
            limit,
            offset
        });

        // Build WHERE clause dynamically based on provided filters
        
        // Add CM code filter if provided
        if (cm_code) {
            whereConditions.push(`scm.cm_code = $${paramIndex}`);
            queryParams.push(cm_code);
            console.log(`✅ Added cm_code filter: ${cm_code}`);
            paramIndex++;
        }

        // Add period ID filter if provided (convert string to integer if needed)
        if (period_id) {
            // Convert period_id to integer if it's a string to match database type
            const periodIdValue = typeof period_id === 'string' ? parseInt(period_id) : period_id;
            whereConditions.push(`scm.period_id = $${paramIndex}`);
            queryParams.push(periodIdValue);
            console.log(`✅ Added period_id filter: ${period_id} (converted to: ${periodIdValue})`);
            paramIndex++;
        }

        // Add SKU code filter if provided
        if (sku_code) {
            whereConditions.push(`scm.sku_code = $${paramIndex}`);
            queryParams.push(sku_code);
            console.log(`✅ Added sku_code filter: ${sku_code}`);
            paramIndex++;
        }

        // Add component code filter if provided
        if (component_code) {
            whereConditions.push(`scm.component_code = $${paramIndex}`);
            queryParams.push(component_code);
            console.log(`✅ Added component_code filter: ${component_code}`);
            paramIndex++;
        }

        // Add packaging type filter if provided
        if (packaging_type) {
            whereConditions.push(`scm.component_packaging_type_id = $${paramIndex}`);
            queryParams.push(packaging_type);
            console.log(`✅ Added packaging_type filter: ${packaging_type}`);
            paramIndex++;
        }

        // Add active status filter if provided
        if (is_active !== undefined && is_active !== null) {
            whereConditions.push(`scm.is_active = $${paramIndex}`);
            queryParams.push(is_active);
            console.log(`✅ Added is_active filter: ${is_active}`);
            paramIndex++;
        }

        // Build the final WHERE clause from all conditions
        const whereClause = whereConditions.length > 0 ? `WHERE ${whereConditions.join(' AND ')}` : '';
        
        // Comprehensive SQL query that joins multiple tables to get complete audit log data
        // This query retrieves data from:
        // - sdp_sku_component_mapping_details (main table)
        // - sdp_skudetails (SKU information)
        // - sdp_component_details (component master data)
        // - sdp_users (user information)
        // - sdp_period (period information)
        // - sdp_material_type (material type master)
        // - sdp_component_uom (UOM master)
        // - sdp_component_base_uom (base UOM master)
        const comprehensiveQuery = `
            SELECT DISTINCT ON (scm.cm_code, scm.sku_code, scm.component_code, scm.version)
                scm.cm_code,
                scm.sku_code,
                scm.component_code,
                scm.version,
                scm.period_id,
                p.period AS period_name,
                scm.component_valid_from,
                scm.component_valid_to,
                scm.component_packaging_type_id AS packaging_type_name,
                cd.component_packaging_material AS packaging_material_name,
                scm.created_by AS mapping_created_by,
                u.username AS mapping_created_by_name,
                scm.created_at AS mapping_created_at,
                scm.updated_at AS mapping_updated_at,
                scm.is_active AS mapping_is_active,
                scm.componentvaliditydatefrom,
                scm.componentvaliditydateto,
                sd.*,
                cd.id AS component_id,
                cd.formulation_reference,
                cd.material_type_id,
                mt.item_name AS material_type_name,
                cd.component_description,
                cd.component_valid_from AS component_master_valid_from,
                cd.component_valid_to AS component_master_valid_to,
                cd.component_material_group,
                cd.component_quantity,
                cd.component_uom_id,
                uom.item_name AS component_uom_name,
                cd.component_base_quantity,
                cd.component_base_uom_id,
                base_uom.item_name AS component_base_uom_name,
                cd.percent_w_w,
                cd.evidence,
                cd.component_packaging_material,
                cd.helper_column,
                cd.component_unit_weight,
                cd.weight_unit_measure_id,
                cd.percent_mechanical_pcr_content,
                cd.percent_mechanical_pir_content,
                cd.percent_chemical_recycled_content,
                cd.percent_bio_sourced,
                cd.material_structure_multimaterials,
                cd.component_packaging_color_opacity,
                cd.component_packaging_level_id,
                cd.component_dimensions,
                cd.packaging_specification_evidence,
                cd.evidence_of_recycled_or_bio_source,
                cd.last_update_date,
                cd.category_entry_id,
                cd.data_verification_entry_id,
                cd.user_id,
                cd.signed_off_by,
                su.username AS signed_off_by_name,
                cd.signed_off_date,
                cd.mandatory_fields_completion_status,
                cd.evidence_provided,
                cd.document_status,
                cd.is_active AS component_is_active,
                cd.created_by AS component_created_by,
                cd.created_date AS component_created_date,
                cd.year,
                cd.component_unit_weight_id,
                cd.periods,
                cd.version AS component_version,
                cd.componentvaliditydatefrom AS component_master_validity_from,
                cd.componentvaliditydateto AS component_master_validity_to
            FROM 
                public.sdp_sku_component_mapping_details scm
            LEFT JOIN public.sdp_skudetails sd 
                ON scm.sku_code = sd.sku_code AND scm.cm_code = sd.cm_code
            LEFT JOIN public.sdp_component_details cd 
                ON scm.component_code = cd.component_code 
                   AND scm.sku_code = cd.sku_code 
                   AND scm.cm_code = sd.cm_code
            LEFT JOIN public.sdp_users u ON scm.created_by = u.username
            LEFT JOIN public.sdp_users su ON cd.signed_off_by = su.id
            LEFT JOIN public.sdp_period p ON scm.period_id = p.id
            LEFT JOIN public.sdp_material_type mt ON cd.material_type_id = mt.item_name
            LEFT JOIN public.sdp_component_uom uom ON cd.component_uom_id = uom.item_name
            LEFT JOIN public.sdp_component_base_uom base_uom ON cd.component_base_uom_id = base_uom.item_name
            ${whereClause}
            ORDER BY 
                scm.cm_code, scm.sku_code, scm.component_code, scm.version
            LIMIT $${paramIndex++} OFFSET $${paramIndex++}
        `;

        // Add pagination parameters to query parameters
        queryParams.push(parseInt(limit), parseInt(offset));

        // Debug logging for query execution
        console.log('🔍 Final Query:', comprehensiveQuery);
        console.log('📊 Query Parameters:', queryParams);
        console.log('🏷️ CM Code Filter:', cm_code);
        console.log('🔧 Where Conditions:', whereConditions);
        console.log('📝 Where Clause:', whereClause);

        // Execute the main query to get audit log data
        const result = await db.query(comprehensiveQuery, queryParams);
        
        console.log('📊 Query executed successfully');
        console.log(`📈 Records returned: ${result.rows.length}`);
        if (result.rows.length > 0) {
            console.log('📋 Sample record structure:', JSON.stringify(result.rows[0], null, 2));
        }

        // Get total count for pagination (without limit/offset)
        // This query gets the total number of records matching the filters for pagination calculation
        const countQuery = `
            SELECT COUNT(DISTINCT (scm.cm_code, scm.sku_code, scm.component_code, scm.version)) as total
            FROM 
                public.sdp_sku_component_mapping_details scm
            LEFT JOIN public.sdp_skudetails sd 
                ON scm.sku_code = sd.sku_code AND scm.cm_code = sd.cm_code
            LEFT JOIN public.sdp_component_details cd 
                ON scm.component_code = cd.component_code 
                   AND scm.sku_code = cd.sku_code 
                   AND scm.cm_code = sd.cm_code
            ${whereConditions.length > 0 ? `WHERE ${whereConditions.join(' AND ')}` : ''}
        `;

        // Execute count query (remove limit/offset parameters for total count)
        const countResult = await db.query(countQuery, queryParams.slice(0, -2));
        const totalCount = parseInt(countResult.rows[0].total);

        // Prepare comprehensive response data with pagination and metadata
        const responseData = {
            success: true,
            message: 'Audit log data retrieved successfully',
            data: {
                // Actual audit log records from the main query
                records: result.rows,
                
                // Pagination information for frontend
                pagination: {
                    total: totalCount,                    // Total records matching filters
                    limit: parseInt(limit),              // Records per page
                    offset: parseInt(offset),            // Current page offset
                    has_more: (parseInt(offset) + parseInt(limit)) < totalCount,  // More pages available
                    current_page: Math.floor(parseInt(offset) / parseInt(limit)) + 1,  // Current page number
                    total_pages: Math.ceil(totalCount / parseInt(limit))  // Total number of pages
                },
                
                // Applied filters for reference
                filters_applied: {
                    cm_code,
                    period_id,
                    sku_code,
                    component_code,
                    packaging_type,
                    is_active
                },
                
                // Query execution summary
                query_summary: {
                    cm_code: cm_code || 'All CM Codes',  // CM code used in query
                    total_records: totalCount,           // Total records found
                    returned_records: result.rows.length, // Records returned in this response
                    query_executed_at: new Date().toISOString()  // Timestamp of query execution
                }
            }
        };

        // Send successful response with audit log data
        return reply.send(responseData);

    } catch (error) {
        // Handle any errors that occur during query execution
        console.error('❌ Error in getAuditLog:', error);
        return reply.code(500).send({
            success: false,
            message: 'Internal server error while retrieving audit log data',
            error: error.message
        });
    }
};

// Export the controller function for use in routes
module.exports = {
    getAuditLog
};
