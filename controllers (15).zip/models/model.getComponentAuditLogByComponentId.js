const pool = require('../config/db.config');

/**
 * Get component audit log records by component_id from mapping table only (legacy function)
 */
async function getComponentAuditLogByComponentIdLegacy(componentId) {
  const query = `
    SELECT id, cm_code, sku_code, component_code, version, component_packaging_type_id,
           period_id, component_valid_from, component_valid_to, created_by, action_type,
           action_reason, old_values, new_values, changed_by, changed_at, change_summary,
           componentvaliditydatefrom, componentvaliditydateto, componentid
    FROM sdp_sku_component_mapping_details_auditlog 
    WHERE componentid = $1 
    ORDER BY changed_at DESC
  `;

  const result = await pool.query(query, [componentId]);
  return result.rows;
}

/**
 * Get ALL component audit log records by component_id from both tables
 * This will get ALL entries from BOTH tables for the given component_id
 */
async function getComponentAuditLogByComponentId(componentId) {
  const query = `
    -- Get ALL data from sdp_component_details_auditlog table
    SELECT 
      'details' as table_source,
      NULL as mapping_id,
      NULL as cm_code,
      NULL as sku_code,
      NULL as component_code,
      NULL as mapping_version,
      NULL as component_packaging_type_id,
      NULL as period_id,
      NULL as mapping_component_valid_from,
      NULL as mapping_component_valid_to,
      NULL as mapping_created_by,
      NULL as action_type,
      NULL as action_reason,
      NULL as old_values,
      NULL as new_values,
      NULL as mapping_changed_by,
      NULL as mapping_changed_at,
      NULL as mapping_change_summary,
      NULL as mapping_componentvaliditydatefrom,
      NULL as mapping_componentvaliditydateto,
      NULL as componentid,
      
      -- Component details table fields
      cd.id as details_id,
      cd.component_id,
      cd.formulation_reference,
      cd.material_type_id,
      cd.components_reference,
      cd.component_description,
      cd.version as details_version,
      cd.componentvaliditydatefrom as details_componentvaliditydatefrom,
      cd.componentvaliditydateto as details_componentvaliditydateto,
      cd.component_material_group,
      cd.component_quantity,
      cd.component_uom_id,
      cd.component_base_quantity,
      cd.component_base_uom_id,
      cd.percent_w_w,
      cd.evidence,
      cd.component_packaging_material,
      cd.helper_column,
      cd.component_unit_weight,
      cd.weight_unit_measure_id,
      cd.percent_mechanical_pcr_content,
      cd.percent_mechanical_pir_content,
      cd.percent_chemical_recycled_content,
      cd.percent_bio_sourced,
      cd.material_structure_multimaterials,
      cd.component_packaging_color_opacity,
      cd.component_packaging_level_id,
      cd.component_dimensions,
      cd.packaging_specification_evidence,
      cd.evidence_of_recycled_or_bio_source,
      cd.last_update_date,
      cd.category_entry_id,
      cd.data_verification_entry_id,
      cd.user_id,
      cd.signed_off_by,
      cd.signed_off_date,
      cd.mandatory_fields_completion_status,
      cd.evidence_provided,
      cd.document_status,
      cd.is_active,
      cd.created_by as details_created_by,
      cd.created_date as details_created_date,
      cd.year,
      cd.component_unit_weight_id,
      cd.periods as details_periods
      
    FROM sdp_component_details_auditlog cd
    WHERE cd.component_id = $1
    
    UNION ALL
    
    -- Get ALL data from sdp_sku_component_mapping_details_auditlog table
    SELECT 
      'mapping' as table_source,
      m.id as mapping_id,
      m.cm_code,
      m.sku_code,
      m.component_code,
      m.version as mapping_version,
      m.component_packaging_type_id,
      m.period_id,
      m.component_valid_from as mapping_component_valid_from,
      m.component_valid_to as mapping_component_valid_to,
      m.created_by as mapping_created_by,
      m.action_type,
      m.action_reason,
      m.old_values,
      m.new_values,
      m.changed_by as mapping_changed_by,
      m.changed_at as mapping_changed_at,
      m.change_summary as mapping_change_summary,
      m.componentvaliditydatefrom as mapping_componentvaliditydatefrom,
      m.componentvaliditydateto as mapping_componentvaliditydateto,
      m.componentid,
      
      -- NULL for component details fields
      NULL as details_id,
      NULL as component_id,
      NULL as formulation_reference,
      NULL as material_type_id,
      NULL as components_reference,
      NULL as component_description,
      NULL as details_version,
      NULL as details_componentvaliditydatefrom,
      NULL as details_componentvaliditydateto,
      NULL as component_material_group,
      NULL as component_quantity,
      NULL as component_uom_id,
      NULL as component_base_quantity,
      NULL as component_base_uom_id,
      NULL as percent_w_w,
      NULL as evidence,
      NULL as component_packaging_material,
      NULL as helper_column,
      NULL as component_unit_weight,
      NULL as weight_unit_measure_id,
      NULL as percent_mechanical_pcr_content,
      NULL as percent_mechanical_pir_content,
      NULL as percent_chemical_recycled_content,
      NULL as percent_bio_sourced,
      NULL as material_structure_multimaterials,
      NULL as component_packaging_color_opacity,
      NULL as component_packaging_level_id,
      NULL as component_dimensions,
      NULL as packaging_specification_evidence,
      NULL as evidence_of_recycled_or_bio_source,
      NULL as last_update_date,
      NULL as category_entry_id,
      NULL as data_verification_entry_id,
      NULL as user_id,
      NULL as signed_off_by,
      NULL as signed_off_date,
      NULL as mandatory_fields_completion_status,
      NULL as evidence_provided,
      NULL as document_status,
      NULL as is_active,
      NULL as details_created_by,
      NULL as details_created_date,
      NULL as year,
      NULL as component_unit_weight_id,
      NULL as details_periods
      
    FROM sdp_sku_component_mapping_details_auditlog m
    WHERE m.componentid = $1
    
    ORDER BY 
      table_source ASC,
      COALESCE(mapping_changed_at, details_created_date) DESC
  `;

  const result = await pool.query(query, [componentId]);
  return result.rows;
}

module.exports = { 
  getComponentAuditLogByComponentId,
  getComponentAuditLogByComponentIdLegacy
}; 