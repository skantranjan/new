import React, { useState, useEffect } from 'react';
import Layout from '../components/Layout';
import Loader from '../components/Loader';
import { Collapse } from 'react-collapse';
import { apiGet, apiPostWithParams } from '../utils/api';
import * as ExcelJS from 'exceljs';

/**
 * Audit Log Entry Interface
 * Defines the structure of audit log data
 */
interface AuditLogEntry {
  id: number;
  action: string;
  entity_type: 'sku' | 'component';
  entity_id: number;
  entity_code: string;
  entity_description: string;
  old_value?: string;
  new_value?: string;
  user_id: number;
  created_by: string;
  created_date: string;
  cm_code: string;
  cm_description?: string;
  sku_code?: string;
  component_code?: string;
  details?: any;
}

/**
 * Master Data Response Interface
 * Defines the structure of the consolidated master data API response
 */
interface MasterDataResponse {
  success: boolean;
  message: string;
  data: {
    periods?: Array<{id: number, period: string, is_active: boolean}>;
    regions?: Array<{id: number, name: string}>;
    material_types?: Array<{id: number, item_name: string, item_order: number, is_active: boolean}>;
    component_uoms?: Array<{id: number, item_name: string, item_order: number, is_active: boolean}>;
    packaging_materials?: Array<{id: number, item_name: string, item_order: number, is_active: boolean}>;
    packaging_levels?: Array<{id: number, item_name: string, item_order: number, is_active: boolean}>;
    component_base_uoms?: Array<{id: number, item_name: string, item_order: number, is_active: boolean}>;
    component_codes?: Array<{component_code: string, component_description: string}>;
    total_count?: {
      periods: number;
      regions: number;
      material_types: number;
      component_uoms: number;
      packaging_materials: number;
      packaging_levels: number;
      component_base_uoms: number;
      component_codes: number;
    };
  };
}

/**
 * CM Codes Response Interface
 */
interface CmCodesResponse {
  success: boolean;
  message: string;
  data: Array<{
    id: number;
    cm_code: string;
    cm_description: string;
    is_active: boolean;
  }>;
}

/**
 * Filter Options Interface
 */
interface FilterOptions {
  period: string;
  cmCode: string;
  skuCode: string;
  componentCode: string;
}

/**
 * Audit Log Page Component
 * Displays comprehensive audit trail for SKUs and components
 */
const AuditLog: React.FC = () => {
  // ===== STATE MANAGEMENT =====
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [filterLoading, setFilterLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [openIndex, setOpenIndex] = useState<number | null>(null);
  const [apiStatus, setApiStatus] = useState<'connected' | 'disconnected' | 'checking'>('checking');
  const [paginationInfo, setPaginationInfo] = useState<any>(null);
  const [querySummary, setQuerySummary] = useState<any>(null);

  // Filter states
  const [filters, setFilters] = useState<FilterOptions>({
    period: '',
    cmCode: '',
    skuCode: '',
    componentCode: ''
  });

  // Master data states
  const [cmCodes, setCmCodes] = useState<string[]>([]);
  const [periods, setPeriods] = useState<Array<{id: number, period: string, is_active: boolean}>>([]);
  const [componentCodes, setComponentCodes] = useState<Array<{component_code: string, component_description: string}>>([]);

  // ===== INITIAL DATA LOADING =====
  useEffect(() => {
    // Load initial data without filters
    fetchAuditLogs();
    loadMasterData();
  }, []);

  // Debug periods state changes
  useEffect(() => {
    console.log('🔍 Periods state changed:', periods);
  }, [periods]);

  // ===== API FUNCTIONS =====
  
  /**
   * Fetch audit log data from API
   */
  const fetchAuditLogs = async () => {
    try {
      if (auditLogs.length === 0) {
        setLoading(true);
      } else {
        setFilterLoading(true);
      }
      setError(null);
      setApiStatus('checking');

      // Build filter parameters for the API call
      const filterParams: any = {};
      
      if (filters.cmCode) {
        filterParams.cm_code = filters.cmCode;
      }
      
      if (filters.skuCode) {
        filterParams.sku_code = filters.skuCode;
      }
      
      if (filters.componentCode) {
        filterParams.component_code = filters.componentCode;
      }
      
      if (filters.period) {
        filterParams.period = filters.period;
      }

      // Make API call to the real endpoint
      const requestBody = {
        filters: filterParams,
        timestamp: new Date().toISOString()
      };
      
      const response = await apiPostWithParams('/audit-logs', undefined, requestBody);
      
      // Log the data received from the API
      console.log('Audit Logs API Response:', response);
      console.log('Filter Parameters:', filterParams);
      console.log('Request Body:', requestBody);
      
      if (response.success && response.data) {
        // Handle the new API response structure
        if (response.data.records && Array.isArray(response.data.records)) {
          setAuditLogs(response.data.records);
          
          // Log pagination info
          if (response.data.pagination) {
            console.log('Pagination Info:', response.data.pagination);
            setPaginationInfo(response.data.pagination);
          }
          
          // Log filters applied
          if (response.data.filters_applied) {
            console.log('Filters Applied:', response.data.filters_applied);
          }
          
          // Log query summary
          if (response.data.query_summary) {
            console.log('Query Summary:', response.data.query_summary);
            setQuerySummary(response.data.query_summary);
          }
        } else {
          setAuditLogs([]);
          setError('Invalid data structure received from API');
        }
        setApiStatus('connected');
        setError(null);
      } else {
        // If no data or error, set empty array
        setAuditLogs([]);
        if (response.message) {
          setError(response.message);
        } else {
          setError('No data received from API');
        }
        setApiStatus('connected');
      }
      
    } catch (err) {
      console.error('Error in fetchAuditLogs:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch audit logs');
      setAuditLogs([]);
      setApiStatus('disconnected');
    } finally {
      setLoading(false);
      setFilterLoading(false);
    }
  };

  /**
   * Load master data for filters
   */
  const loadMasterData = async () => {
    try {
      // Load CM codes from /cm-codes API
      const cmResponse: CmCodesResponse = await apiGet('/cm-codes');
      if (cmResponse.success && cmResponse.data) {
        const activeCmCodes = cmResponse.data
          .filter(cm => cm.is_active)
          .map(cm => cm.cm_code);
        setCmCodes(activeCmCodes);
      }
      
      // Load periods and component codes from /masterdata API
      console.log('🔍 Fetching masterdata from API...');
      const masterDataResponse: MasterDataResponse = await apiGet('/masterdata');
      console.log('🔍 Masterdata API Response:', masterDataResponse);
      
      if (masterDataResponse.success && masterDataResponse.data) {
        console.log('🔍 Masterdata data received:', masterDataResponse.data);
        
        // Load periods - only the highest ID (latest period)
        if (masterDataResponse.data.periods) {
          console.log('🔍 Raw periods data:', masterDataResponse.data.periods);
          
          const activePeriods = masterDataResponse.data.periods
            .filter(period => period.is_active);
          console.log('🔍 Active periods after filter:', activePeriods);
          
          const sortedPeriods = activePeriods.sort((a, b) => b.id - a.id);
          console.log('🔍 Periods after sorting (desc):', sortedPeriods);
          
          // Take only the highest ID period
          const latestPeriod = sortedPeriods.length > 0 ? [sortedPeriods[0]] : [];
          console.log('🔍 Latest period to set:', latestPeriod);
          
          setPeriods(latestPeriod);
          console.log('✅ Periods state updated with:', latestPeriod);
        } else {
          console.log('❌ No periods data found in API response');
        }
        
        // Load component codes
        if ((masterDataResponse.data as any).component_codes) {
          setComponentCodes((masterDataResponse.data as any).component_codes);
          console.log('Loaded component codes:', (masterDataResponse.data as any).component_codes);
        }
      }
      
    } catch (err) {
      console.error('Error loading master data:', err);
      // No fallback data - let the UI handle empty states gracefully
      setCmCodes([]);
      setPeriods([]);
      setComponentCodes([]);
    }
  };

  // ===== FILTER HANDLERS =====
  
  const handleFilterChange = (field: keyof FilterOptions, value: string) => {
    setFilters(prev => ({ ...prev, [field]: value }));
    // Remove auto-filtering - only filter when button is clicked
  };

  const handleSearch = () => {
    fetchAuditLogs();
  };

  const handleClearFilters = () => {
    setFilters({
      period: '',
      cmCode: '',
      skuCode: '',
      componentCode: ''
    });
    // Fetch all data when filters are cleared
    setTimeout(() => {
      fetchAuditLogs();
    }, 100);
  };

  // ===== HELPER FUNCTIONS =====
  
  const getValidRecordsCount = () => {
    return auditLogs.filter(log => log && Object.keys(log).length > 0).length;
  };

  const getActionIcon = (action: string) => {
    switch (action) {
      case 'CREATE': return 'ri-add-circle-line';
      case 'UPDATE': return 'ri-edit-line';
      case 'STATUS_CHANGE': return 'ri-toggle-line';
      case 'DELETE': return 'ri-delete-bin-line';
      default: return 'ri-file-list-line';
    }
  };

  const getActionColor = (action: string) => {
    switch (action) {
      case 'CREATE': return '#28a745';
      case 'UPDATE': return '#007bff';
      case 'STATUS_CHANGE': return '#ffc107';
      case 'DELETE': return '#dc3545';
      default: return '#6c757d';
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const toggleCollapse = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  // ===== RENDER FUNCTIONS =====
  
  const renderFilters = () => (
    <div style={{
      background: '#f8f9fa',
      border: '1px solid #e9ecef',
      borderRadius: '8px',
      padding: '20px',
      marginBottom: '20px'
    }}>
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
        gap: '20px',
        alignItems: 'end'
      }}>
        {/* Period Filter */}
        <div>
          <label style={{
            display: 'block',
            marginBottom: '8px',
            fontWeight: '600',
            color: '#495057',
            fontSize: '14px'
          }}>
            Period
          </label>
          <select
            value={filters.period}
            onChange={(e) => handleFilterChange('period', e.target.value)}
            style={{
              width: '100%',
              padding: '10px 12px',
              borderRadius: '6px',
              fontSize: '14px',
              backgroundColor: '#fff',
              border: '1px solid #ced4da',
              outline: 'none',
              transition: 'border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out'
            }}
            onFocus={(e) => {
              const target = e.target as HTMLSelectElement;
              target.style.borderColor = '#30ea03';
            }}
            onBlur={(e) => {
              const target = e.target as HTMLSelectElement;
              target.style.borderColor = '#ced4da';
            }}
          >
            <option value="">
              {periods.length === 0 ? 'No periods available' : 'Select Period'}
            </option>
            {periods.map(period => (
              <option key={period.id} value={period.period}>{period.period}</option>
            ))}
          </select>
        </div>

        {/* CM Code Filter */}
        <div>
          <label style={{
            display: 'block',
            marginBottom: '8px',
            fontWeight: '600',
            color: '#495057',
            fontSize: '14px'
          }}>
            CM Code
          </label>
          <select
            value={filters.cmCode}
            onChange={(e) => handleFilterChange('cmCode', e.target.value)}
            style={{
              width: '100%',
              padding: '10px 12px',
              borderRadius: '6px',
              fontSize: '14px',
              backgroundColor: '#fff',
              border: '1px solid #ced4da',
              outline: 'none',
              transition: 'border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out'
            }}
            onFocus={(e) => {
              const target = e.target as HTMLSelectElement;
              target.style.borderColor = '#30ea03';
            }}
            onBlur={(e) => {
              const target = e.target as HTMLSelectElement;
              target.style.borderColor = '#ced4da';
            }}
          >
            <option value="">
              {cmCodes.length === 0 ? 'No CM codes available' : 'Select CM Code'}
            </option>
            {cmCodes.map(code => (
              <option key={code} value={code}>{code}</option>
            ))}
          </select>
        </div>


        {/* Component Code Filter */}
        <div>
          <label style={{
            display: 'block',
            marginBottom: '8px',
            fontWeight: '600',
            color: '#495057',
            fontSize: '14px'
          }}>
            Component Code
          </label>
          <select
            value={filters.componentCode}
            onChange={(e) => handleFilterChange('componentCode', e.target.value)}
            style={{
              width: '100%',
              padding: '10px 12px',
              borderRadius: '6px',
              fontSize: '14px',
              backgroundColor: '#fff',
              border: '1px solid #ced4da',
              outline: 'none',
              transition: 'border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out'
            }}
            onFocus={(e) => {
              const target = e.target as HTMLSelectElement;
              target.style.borderColor = '#30ea03';
            }}
            onBlur={(e) => {
              const target = e.target as HTMLSelectElement;
              target.style.borderColor = '#ced4da';
            }}
          >
            <option value="">
              {componentCodes.length === 0 ? 'No component codes available' : 'Select Component Code'}
            </option>
            {componentCodes.map(component => (
              <option key={component.component_code} value={component.component_code}>
                {component.component_code} - {component.component_description || 'No description'}
              </option>
            ))}
          </select>
        </div>

        {/* Filter Buttons */}
        <div style={{
          display: 'flex',
          gap: '10px',
          alignItems: 'end'
        }}>
          <button 
            onClick={handleSearch} 
            disabled={loading || filterLoading}
            style={{
              padding: '10px 20px',
              backgroundColor: '#30ea03',
              color: '#000',
              border: 'none',
              borderRadius: '6px',
              fontSize: '14px',
              fontWeight: '600',
              cursor: loading || filterLoading ? 'not-allowed' : 'pointer',
              opacity: loading || filterLoading ? 0.7 : 1,
              transition: 'all 0.2s ease-in-out',
              display: 'flex',
              alignItems: 'center',
              gap: '8px'
            }}
            onMouseOver={(e) => {
              if (!loading && !filterLoading) {
                const target = e.target as HTMLButtonElement;
                target.style.backgroundColor = '#28d100';
                target.style.transform = 'translateY(-1px)';
              }
            }}
            onMouseOut={(e) => {
              if (!loading && !filterLoading) {
                const target = e.target as HTMLButtonElement;
                target.style.backgroundColor = '#30ea03';
                target.style.transform = 'translateY(0)';
              }
            }}
          >
            <i className="ri-search-line"></i>
            {filterLoading ? 'Filtering...' : 'Apply Filters'}
          </button>
          
          <button 
            onClick={handleClearFilters}
            style={{
              padding: '10px 20px',
              backgroundColor: '#6c757d',
              color: '#fff',
              border: 'none',
              borderRadius: '6px',
              fontSize: '14px',
              fontWeight: '600',
              cursor: 'pointer',
              transition: 'all 0.2s ease-in-out',
              display: 'flex',
              alignItems: 'center',
              gap: '8px'
            }}
            onMouseOver={(e) => {
              const target = e.target as HTMLButtonElement;
              target.style.backgroundColor = '#5a6268';
              target.style.transform = 'translateY(-1px)';
            }}
            onMouseOut={(e) => {
              const target = e.target as HTMLButtonElement;
              target.style.backgroundColor = '#6c757d';
              target.style.transform = 'translateY(0)';
            }}
          >
            <i className="ri-refresh-line"></i>
            Reset
          </button>
        </div>
      </div>

      {/* Loading indicator */}
      {filterLoading && (
        <div style={{
          marginTop: '15px',
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
          color: '#30ea03',
          fontSize: '14px'
        }}>
          <i className="ri-loader-4-line" style={{ 
            animation: 'spin 1s linear infinite'
          }}></i>
          Applying filters...
        </div>
      )}
    </div>
  );

  const renderAuditLogs = () => (
    <div className="row" style={{ marginTop: '20px' }}>
      <div className="col-sm-12">
        {auditLogs
          .filter(log => log && Object.keys(log).length > 0) // Filter out empty objects
          .map((log, index) => (
          <div key={log.id || index} className="panel panel-default" style={{ marginBottom: '10px' }}>
            <div 
              className="panel-heading" 
              style={{ 
                cursor: 'pointer',
                padding: '4px 10px 4px 5px',
                backgroundColor: '#000',
                border: '1px solid #000',
                borderRadius: '4px',
                color: 'white'
              }}
              onClick={() => toggleCollapse(index)}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
                  <div style={{
                    width: '24px',
                    height: '24px',
                    backgroundColor: '#30ea03',
                    borderRadius: '50%',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}>
                    <i 
                      className={openIndex === index ? "ri-subtract-line" : "ri-add-line"}
                      style={{ 
                        color: 'white', 
                        fontSize: '16px',
                        fontWeight: 'bold'
                      }}
                    />
                  </div>
                  <div>
                    <span style={{ 
                      fontWeight: '600',
                      fontSize: '16px',
                      marginRight: '10px'
                    }}>
                      {log.entity_code || 'N/A'} || {log.entity_description || 'N/A'}
                    </span>
                  </div>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
                  <i 
                    className={`ri-arrow-down-s-line ${openIndex === index ? 'ri-arrow-up-s-line' : ''}`}
                    style={{ fontSize: '18px', color: 'white' }}
                  />
                </div>
              </div>
            </div>
            
            <Collapse isOpened={openIndex === index}>
              <div className="panel-body" style={{ minHeight: 80, padding: 24, position: 'relative' }}>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '20px' }}>
                  <div>
                    <h6 style={{ fontWeight: '600', marginBottom: '10px', color: '#333' }}>Entity Details</h6>
                    <p><strong>Entity Type:</strong> {log.entity_type ? log.entity_type.toUpperCase() : 'N/A'}</p>
                    <p><strong>Entity Code:</strong> {log.entity_code || 'N/A'}</p>
                    <p><strong>Entity Description:</strong> {log.entity_description || 'N/A'}</p>
                    {log.sku_code && <p><strong>SKU Code:</strong> {log.sku_code}</p>}
                    {log.component_code && <p><strong>Component Code:</strong> {log.component_code}</p>}
                  </div>
                  
                  <div>
                    <h6 style={{ fontWeight: '600', marginBottom: '10px', color: '#333' }}>CM Information</h6>
                    <p><strong>CM Code:</strong> {log.cm_code || 'N/A'}</p>
                    {log.cm_description && <p><strong>CM Description:</strong> {log.cm_description}</p>}
                  </div>
                  
                  <div>
                    <h6 style={{ fontWeight: '600', marginBottom: '10px', color: '#333' }}>Change Details</h6>
                    {log.old_value && log.new_value ? (
                      <>
                        <p><strong>From:</strong> <span style={{ color: '#dc3545' }}>{log.old_value}</span></p>
                        <p><strong>To:</strong> <span style={{ color: '#28a745' }}>{log.new_value}</span></p>
                      </>
                    ) : (
                      <p><strong>Details:</strong> {log.action ? (log.action === 'CREATE' ? 'New entry created' : 'Details updated') : 'N/A'}</p>
                    )}
                  </div>
                  
                  <div>
                    <h6 style={{ fontWeight: '600', marginBottom: '10px', color: '#333' }}>User Information</h6>
                    <p><strong>User:</strong> {log.created_by || 'N/A'}</p>
                    <p><strong>User ID:</strong> {log.user_id || 'N/A'}</p>
                    <p><strong>Date:</strong> {log.created_date ? formatDate(log.created_date) : 'N/A'}</p>
                  </div>
                </div>
              </div>
            </Collapse>
          </div>
        ))}
        
        {auditLogs.length === 0 && !loading && (
          <div style={{ 
            textAlign: 'center', 
            padding: '40px 20px', 
            color: '#666',
            fontSize: '16px'
          }}>
            <i className="ri-file-list-line" style={{ fontSize: '48px', color: '#ccc', marginBottom: '16px' }}></i>
            <p>
              {Object.values(filters).some(f => f !== '') 
                ? 'No audit log entries found for the selected filters. Try adjusting your search criteria.'
                : 'No audit log entries found in the system.'
              }
            </p>
            {Object.values(filters).some(f => f !== '') && (
              <button 
                onClick={handleClearFilters}
                style={{
                  marginTop: '15px',
                  padding: '8px 16px',
                  backgroundColor: '#30ea03',
                  color: '#000',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  fontWeight: '600'
                }}
              >
                Clear All Filters
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );

  // ===== MAIN RENDER =====
  
  if (loading && auditLogs.length === 0) {
    return (
      <Layout>
        <Loader />
      </Layout>
    );
  }

  return (
    <Layout>
      <style>
        {`
          @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
          }
        `}
      </style>
      <div className="mainInternalPages">
        {/* Page Header */}
        <div style={{ 
          display: 'flex', 
          justifyContent: 'space-between', 
          alignItems: 'center',
          padding: '12px 0'
        }}>
          <div className="commonTitle">
            <div className="icon">
              <i className="ri-file-list-line"></i>
            </div>
            <h1>Audit Log</h1>
          </div>
        </div>

        {/* Error Display */}
        {error && (
          <div style={{ 
            background: '#f8d7da', 
            color: '#721c24', 
            padding: '15px', 
            borderRadius: '4px', 
            marginBottom: '20px',
            border: '1px solid #f5c6cb'
          }}>
            <i className="ri-error-warning-line" style={{ marginRight: '8px' }}></i>
            {error}
          </div>
        )}

        {/* Master Data Loading Status */}
        {(cmCodes.length === 0 || periods.length === 0 || componentCodes.length === 0) && (
          <div style={{ 
            background: '#fff3cd', 
            color: '#856404', 
            padding: '15px', 
            borderRadius: '4px', 
            marginBottom: '20px',
            border: '1px solid #ffeaa7'
          }}>
            <i className="ri-information-line" style={{ marginRight: '8px' }}></i>
            <strong>Note:</strong> Some filter options may not be available due to API connectivity issues. 
            Only the latest active period is shown.
          </div>
        )}


        {/* Debug Information */}
        {apiStatus === 'disconnected' && (
          <div style={{ 
            background: '#e7f3ff', 
            color: '#0c5460', 
            padding: '15px', 
            borderRadius: '4px', 
            marginBottom: '20px',
            border: '1px solid #bee5eb',
            fontSize: '14px'
          }}>
            <i className="ri-bug-line" style={{ marginRight: '8px' }}></i>
            <strong>Debug Info:</strong>
            <div style={{ marginTop: '8px', fontFamily: 'monospace' }}>
              <div><strong>API Endpoint:</strong> POST http://localhost:3000/audit-logs</div>
              <div><strong>Content-Type:</strong> application/json</div>
              <div><strong>Authorization:</strong> Bearer Qw8!zR2@pL6</div>
              <div><strong>Current Filters:</strong> {JSON.stringify(filters, null, 2)}</div>
            </div>
          </div>
        )}

        {/* 3PM Information Banner */}
        <div className="filters CMDetails">
          <div className="row">
            <div className="col-sm-12 ">
              <ul style={{ display: 'flex', alignItems: 'center', padding: '6px 15px 8px' }}>
                <li><strong>Total Records: </strong> {paginationInfo?.total || 0}</li>
                <li> | </li>
                <li><strong>Page: </strong> {paginationInfo?.current_page || 1} of {paginationInfo?.total_pages || 1}</li>
                <li> | </li>
                <li>
                  <strong>Status: </strong>
                  <span style={{
                    display: 'inline-block',
                    marginLeft: 8,
                    padding: '1px 14px',
                    borderRadius: 12,
                    background: '#30ea03',
                    color: '#000',
                    fontWeight: 600
                  }}>
                    Active
                  </span>
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* Filters */}
        {renderFilters()}

        {/* Audit Logs */}
        {renderAuditLogs()}
      </div>
    </Layout>
  );
};

export default AuditLog;
