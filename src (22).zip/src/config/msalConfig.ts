import { Configuration, PopupRequest } from "@azure/msal-browser";

// MSAL configuration for Azure AD
export const msalConfig: Configuration = {
  auth: {
    clientId: "6d727ebc-0df4-4edb-8ad3-afdbc9d2264d",
    authority: "https://login.microsoftonline.com/d1e23d19-ded6-4d66-850c-0d4f35bf2edc",
    redirectUri: process.env.NODE_ENV === 'development' 
      ? "http://localhost:3000/ui" 
      : "https://sustainability-data-portal.eip.dev.haleon.com/ui",
    postLogoutRedirectUri: process.env.NODE_ENV === 'development' 
      ? "http://localhost:3000/ui" 
      : "https://sustainability-data-portal.eip.dev.haleon.com/ui",
  },
  cache: {
    cacheLocation: "sessionStorage", // Use sessionStorage for better security
    storeAuthStateInCookie: false, // Set to true if you have issues with IE11/Edge
  },
  system: {
    loggerOptions: {
      loggerCallback: (level: any, message: string, containsPii: boolean) => {
        if (containsPii) {
          return;
        }
        switch (level) {
          case 0:
            console.log(message);
            return;
          case 1:
            console.warn(message);
            return;
          case 2:
            console.error(message);
            return;
          case 3:
            console.info(message);
            return;
          default:
            console.log(message);
            return;
        }
      },
      logLevel: process.env.NODE_ENV === 'development' ? 0 : 2, // Verbose in dev, Error in prod
    },
  },
};

// Login request configuration
export const loginRequest: PopupRequest = {
  scopes: ["User.Read", "email", "profile"],
  prompt: "select_account", // Force account selection
};

// Logout request configuration
export const logoutRequest = {
  postLogoutRedirectUri: process.env.NODE_ENV === 'development' 
    ? "http://localhost:3000/ui" 
    : (process.env.REACT_APP_POST_LOGOUT_REDIRECT_URI || "https://sustainability-data-portal.eip.dev.haleon.com/ui"),
};

// Graph API endpoints for user info
export const graphConfig = {
  graphMeEndpoint: "https://graph.microsoft.com/v1.0/me",
};
